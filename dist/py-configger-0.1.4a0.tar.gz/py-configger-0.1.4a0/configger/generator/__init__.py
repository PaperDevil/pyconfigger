from configger import BasicConfig


class ConfigGenerator:
    """TODO: Генерировать конифиги YAML и JSON"""
    def __init__(self, config: BasicConfig):
        ...
