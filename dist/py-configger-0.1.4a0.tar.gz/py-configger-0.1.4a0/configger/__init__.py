__version__ = "0.1.4-alpha"  # https://www.python.org/dev/peps/pep-0386/

from configger.config import BasicConfig, SingleConfig