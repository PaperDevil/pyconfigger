from configger.config.basic_config import BasicConfig
from configger.config.single_config import SingleConfig